#include <sys/types.h> 
#include <sys/stat.h>
#include <sys/time.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>

char type(mode_t);
char *perm(mode_t);
void printStat(char*,char*, struct stat*);

/* 디렉터리 내의 파일 이름들을 리스트한다. */
int main(int argc, char **argv) 
{
	DIR *dp;
	char *dir;
	struct dirent *d;
	struct stat st;
	char path[BUFSIZ+1];

	dir = "."; 	// 현재 디렉터리를 대상으로 

	if(argc == 1) { // dl 명령만 주었을때 
		if ((dp = opendir(dir)) == 0) {  // 디렉터리 열기
			perror(dir);
			exit(1);
		}
		while ((d = readdir(dp)) != 0)	// 디렉터리 내의 각 엔트리에 대해
			if(strcmp(d->d_name,".") == 0 || strcmp(d->d_name,"..") == 0)
				continue; // 비교하여  . .. 이 있을때 계속
			else
				printf("%s  ", d->d_name);    // 파일 이름 프린트
		closedir(dp);
		printf("\n");
	}
	else if(strcmp(argv[1],"-a") == 0){ // -a 옵션
	//argv[0]은 dl 이고 -a가 argv[1] 이므로 두개를 비교해서 일치하면 옵션 -a 일때 실행
		if ((dp = opendir(dir)) == 0)   // 디렉터리 열기 
			perror(dir);
	
		while ((d = readdir(dp)) != 0)  // 디렉터리 내의 각 엔트리에 대해 
			printf("%s  ", d->d_name);    // 파일 이름 프린트 
	
		closedir(dp);
		printf("\n");
	}
	else if(strcmp(argv[1],"-l") == 0){ // -ㅣ 옵션
	//argv[0]은 dl 이고 -l이 argv[1] 이므로 두개를 비교해서 일치하면 옵션 -l 일때 실행
		if ((dp = opendir(dir)) == 0)  // 디렉토리 열기 
			perror(dir);

		while ((d = readdir(dp)) != 0) {	// 디렉토리 내의 각 파일에 대해 
			sprintf(path, "%s/%s", dir, d->d_name); // 파일경로명 만들기 
			if (lstat(path, &st) < 0) 	// 파일 상태 정보 가져오기  
				perror(path);
			else if(strcmp(d->d_name,".") == 0 || strcmp(d->d_name,"..") == 0)
				continue;
			else 
				printStat(path, d->d_name, &st);  // 상태 정보 출력
		}
		
		closedir(dp);
	}
	else if(strcmp(argv[1],"-al") == 0){ // -al 옵션
	//argv[0]은 dl 이고 -al 이 argv[1] 이므로 두개를 비교해서 일치하면 옵션 -al 일때 실행
		if ((dp = opendir(dir)) == 0)	// 디렉토리 열기
			perror(dir);

		while ((d = readdir(dp)) != 0) {	//디렉토리 내의 각 파일에 대해
			sprintf(path, "%s/%s", dir, d->d_name);	// 파일경로명 만들기
			if(lstat(path, &st) < 0)	// 파일 상태 정보 가져오기
				perror(path);
			printStat(path, d->d_name, &st); // 상태 정보 출력
		}
		closedir(dp);
	}
	else {
		printf("%s\n","dl\ndl -a\ndl -l\ndl -al\n위 명령들만 사용가능합니다.");
	}
	exit(0);
}

/*파일 상태 정보를 출력 */
void printStat(char *pathname, char *file, struct stat *st) {
	//printf("%5ld ", st->st_blocks);
	printf("%c%s", type(st->st_mode), perm(st->st_mode));
	printf("%3ld ", st->st_nlink);
	printf("%s %s ", getpwuid(st->st_uid)->pw_name, getgrgid(st->st_gid)->gr_name);
	printf("%9ld ", st->st_size);
	printf("%.12s ", ctime(&st->st_mtime)+4);
	printf("%s\n", file);
}

/* 파일 타입을 리턴 */
char type(mode_t mode) {
	
	if (S_ISREG(mode)) 
		return('-');
	if (S_ISDIR(mode)) 
		return('d');
	if (S_ISCHR(mode)) 
		return('c');
	if (S_ISBLK(mode)) 
		return('b');
	if (S_ISLNK(mode)) 
		return('l');
	if (S_ISFIFO(mode)) 
		return('p');
	if (S_ISSOCK(mode)) 
		return('s');
}

/* 파일 허가권을 리턴 */
char* perm(mode_t mode) {
	int i;
	static char perms[10]; 

	strcpy(perms, "---------");
	
	for (i=0; i < 3; i++) {
		if (mode & (S_IREAD >> i*3)) 
			perms[i*3] = 'r';
		if (mode & (S_IWRITE >> i*3)) 
			perms[i*3+1] = 'w';
		if (mode & (S_IEXEC >> i*3)) 
			perms[i*3+2] = 'x';
	}
	return(perms);
}

/*
출처 
김주현 교수님 chap5.pdf (list1, list2)
http://blog.naver.com/PostView.nhn?blogId=sharonichoya&logNo=220501242693
http://freewise.tistory.com/28
http://dojang.io/mod/page/view.php?id=346
*/
