<?
echo "Hello PHP world!!";
?>