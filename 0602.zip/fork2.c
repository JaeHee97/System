#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main()
{
	int pid;
	
	pid = fork();
	if(pid == 0) {
		printf("[Child] : hello, world pid = %d\n", getpid());
		printf("[Child] : hello, world pid = %d\n", getpid());
		printf("[Child] : hello, world pid = %d\n", getpid());
		printf("[Child] : hello, world pid = %d\n", getpid());
		printf("[Child] : hello, world pid = %d\n", getpid());
		printf("[Child] : hello, world pid = %d\n", getpid());
	}
	else {
		printf("[Parent] : Hello, world pid = %d\n", getpid());
		printf("[Parent] : Hello, world pid = %d\n", getpid());
		printf("[Parent] : Hello, world pid = %d\n", getpid());
		printf("[Parent] : Hello, world pid = %d\n", getpid());
		printf("[Parent] : Hello, world pid = %d\n", getpid());
		printf("[Parent] : Hello, world pid = %d\n", getpid());
	}
}
